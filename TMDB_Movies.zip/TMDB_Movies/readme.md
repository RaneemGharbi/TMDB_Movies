# (TMDB Movies Analysis)
## by (Raneem Gharbi)


## Dataset

> I used the TMDB Movies dataset from Kaggle.com: https://www.kaggle.com/tmdb/tmdb-movie-metadata. it has 10866 entries and 21 columns, as for the data wrangling process I cleaned duplicated rows, changed incorrect datatypes: id to string instead of int, release_date to datetime instead of string. I also only kept the columns I needed: id, popularity, budget, revenue, original_title, runtime, release_date, vote_count, vote_average, release_year, and deleted zero values from revenue and budget.


## Summary of Findings

>Through the exploration of the TMDB Movies dataset, I noticed that there are some relationships between the variables according to the correlation heatmap such as: relationship between vote count and popularity, also budget and revenue. surprisingly there is also a relationship between vote count and revenue. mosts of the plots are left skewed and the overall trend of the data seems to be increasing over the years except for the vote count and budget which started to decrease from the 2010s.

### Were there any interesting or surprising interactions between features?

>I didn't expect the vote count and budget ,revenue and vote count to be somewhat correlated, I expected vote average to be more correlated but it wasn't according to the correlation heatmap.

### As a summary I will answer the questions:

**1- Do higher budget movies have higher revenues?**

>>yes, as investigated there is a relationship between budget and revenue, most of the highest movies budget fall between the range of 50 million to 200 millions and most of their corresponding revenue values fall between less than 500 million up to 1 billion dollars, which is more defined and correlated than the relationship of the highest revenue movies with their corresponding budget.

**2- How different movie budgets are throughout the years and Is there a relationship between the movie's release year and its budget?**

>>the mean of movies budget is definitely increasing througout the years, and No there is not relationship between the movies release year and its budget as shown previously in the correlation heatmap.

**3- What are the relationships between the variables of TMDB movies dataset?**

>>Through the exploration of the TMDB Movies dataset, I noticed that there are some relationships between the variables according to the correlation heatmap such as: relationship between vote count and popularity, also budget and revenue. surprisingly there is also a relationship between vote count and revenue. mosts of the plots are left skewed and the overall trend of the data seems to be increasing over the years except for the vote count and budget which started to decrease from the 2010s



## Key Insights for Presentation

> I decided to focus on answering the previous 3 questions for the presentation and chose the plots that fitted the answers and logical explanations for them
